<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Derivado de "MI PAGINA WEB"</title> 
        <style>
    
      
        
            h2{color:rgb(252, 0, 164);
                font-size:35px;
            font-style: italic;
             text-align: center;
             text-decoration: underline;}
            body{background-color: rgb(195, 164, 237);}
            p{color:rgb(247, 247, 247);
                font-family: monospace;
            font-size: 17px;
            font-weight: bold;
            font-style: italic;
            line-height: 1,3em;}
            ol{color:rgb(247, 247, 247);
                font-family: monospace;
            font-size: 17px;
            font-weight: bold;
            font-style: italic;
            line-height: 1,3em;}
            h1{color:rgb(252, 0, 164);
                 font-size: 50px;
            font-style: italic;
             text-align: center;}
            #dog{
            background-color:rgb(219, 109, 219);}
             
            
        
         table {
   width: 100%;
   border: 1px ;}

th, td {
   width: 25%;
   text-align: center;
   vertical-align: top;
   border: 1px solid  ;
   border-collapse: collapse;
   padding: 0.6em;
   caption-side: bottom;
   color:White;
   font-family: monospace;
            font-size: 17px;
            font-weight: bold;
            font-style: italic;
            line-height: 1,3em;}
   
   

th {
  background-color:rgb(219, 109, 219); }
  #basic-info {
            background: rgb(232, 142, 232);
            border: 7px dashed rgb(250, 245, 250);}
            
   
            
            .carita{
            color:rgb(255, 255, 255);}  
           
            #dog-une{
                width: 382px;
                border: 10px ridge rgb(255, 252, 255);}
            
             #container {
            width: 400px;
            margin: auto;
            border: 1px solid rgb(252, 252, 252);
            border-top: 10px solid rgb(250, 75, 250);
            padding: 15px;}
            a:hover, a:active, a:focus { 
                background-color: rgb(255, 0, 251);}
                
        
   
        </style>
    </head>
    <body>
    <div id="container">
    <!--espero que les guste me esforse =)!-->
<h1>  todo sobre perritos <span class="carita">:)</span> </h1>

<img id="dog-une" src="https://cdn.kastatic.org/third_party/javascript-khansrc/live-editor/build/images/animals/dogs_collies.png" alt="perros corriendo de color cafe y blanco" width="400">

<div id="basic-info"><h2> informacion basica </h2>

<p>El perro es un mamífero<em> doméstico</em> que pertenece al grupo de los carnívoros.<strong> Es una subespecie del lobo gris, a quien se lo considera como su antepasado</strong>, y tiene semejanzas con los zorros y los chacales.</p>

<p>
Los perros son seres sociales y viven en manadas con otros perros o con <em> humanos</em>. <strong>Suelen vivir 13 o 15 años</strong> y, algunos como la raza pequeña, llegan a los 17 años. La calidad de vida,varia tanto a través de la alimentación como del cuidado de la salud, es un factor que influye en la esperanza de vida.</p>
<!--esta informacion es muy facil!--></div>
<h2>caracteristicas de los perritos</h2>

<ol>
<li>Ser muy afectuosos con los humanos.</li>
<li>Tener un sentido del olfato muy agudo.</li>
<li>Tener un amplio espectro auditivo.</li>
<li>Ser capaces de detectar el movimiento y la luz a la distancia.</li>
<li>Tener una piel externa que se renueva de manera periódica</li>
</ol>
<!--son tan lindos!-->
<h2>Dentición del perro </h2>

<p id="dog">Las razas de perros reconocidas de manera formal superan los 400 tipos en todo el mundo, según la Federación Cinológica Internacional (FCI) que se encarga de controlar y fomentar el pedigrí de los perros, y reconoce los siguientes diez grupos generales</p>


   <table>
            <thead>
                <tr>
                    <th>GRUPO</th>
                    <th>TIPO</th>
               </tr>
            </thead>
            <tbody>
<tr>
          <td>Grupo 1. </td>
          <td> Perros tipo pastor y boyeros</td>
 </tr>
 
 <tr>
         <td>Grupo 2. </td>
         <td> Perros tipo Pinscher y Schnauzer</td>
         
</tr>
          
<tr>
         <td>
Grupo 3
</td>
         <td>Terriers
</td>
         
</tr> 
           
<tr>
            <td>Grupo 4. 

</td>
            <td>Teckels.</td>
             
 </tr>
 
<tr>
        <td>Grupo 5.  </td>
        <td>  Perros tipo Spitz y primitivo. </td>
        
</tr> 
<tr>
<td>Grupo 6. </td>
            <td> Perros tipo sabueso, de rastro y similares.</td>
              </tr>  <tr>
 <td>Grupo 7. </td>
         
<td>Perros de muestra(con habilidad innata para cazar)</td>
</tr>
<tr>
<td>Grupo 8.</td>
<td> Perros de caza en agua y levantadores.</td>
</tr>
<tr>
<td>Grupo 9.</td>
<td> Perros de compañía.</td>
</tr>
<tr>
<td>Grupo 10.</td>
<td> Perros capaces de correr a gran velocidad(lebreles)</td>
</tr>
            </tbody>
        </table>
      <a href="https://mascotasymas.net/perros"> Para mas informacion de clik aqui</a>
       </div>
    </body>
</html>
